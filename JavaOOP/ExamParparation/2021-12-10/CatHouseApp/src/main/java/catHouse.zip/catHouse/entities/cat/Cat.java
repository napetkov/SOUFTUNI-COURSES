package catHouse.entities.cat;

public interface Cat {
    String getName();

    void setName(String name);

    int getKilograms();

    double getPrice();

    void eating();
}
