package viceCity.models.players;

public class MainPlayer extends BasePlayer{
    private static final String NAME_OF_MAIN_PLAYER = "Tommy Vercetti";
    private static final int LIFE_POINT_OF_MAIN_PLAYER = 100;


    public MainPlayer() {
        super(NAME_OF_MAIN_PLAYER, LIFE_POINT_OF_MAIN_PLAYER);
    }
}
