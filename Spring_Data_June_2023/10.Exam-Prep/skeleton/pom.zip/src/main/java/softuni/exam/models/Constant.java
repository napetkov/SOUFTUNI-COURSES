package softuni.exam.models;

public class Constant {
    public final static String INVALID_FORMAT = "Invalid %s";
    public final static String SUCCESSFUL_FORMAT = "Successfully imported  %s %s - %s";

    public static final String COUNTRY = "country";
    public static final String CITY = "city";
    public static final String FORECAST = "forecast";



}
