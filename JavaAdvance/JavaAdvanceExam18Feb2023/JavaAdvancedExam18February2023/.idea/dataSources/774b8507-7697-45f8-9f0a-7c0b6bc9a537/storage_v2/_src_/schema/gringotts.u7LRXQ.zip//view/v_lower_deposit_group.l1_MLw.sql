create definer = root@localhost view v_lower_deposit_group as
select `gringotts`.`wizzard_deposits`.`deposit_group`        AS `deposit_group`,
       avg(`gringotts`.`wizzard_deposits`.`magic_wand_size`) AS `avg(magic_wand_size)`,
       min(`gringotts`.`wizzard_deposits`.`magic_wand_size`) AS `min(magic_wand_size)`
from `gringotts`.`wizzard_deposits`;

